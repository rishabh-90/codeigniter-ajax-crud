Read Me For Kinduct Coding Challenge

PHP Version: 5.6.30
Mysql Version: 15.1
Xamp Used 5.6.30

---Sorting Task Using UnderScore--
I was not able to figure out how to sort title using underscore but was able to sortBy by Last Name

--Gerneral Things---

All the Wriiten Javascript for achieving this functionality re included  in the View 

Bootstrap, Jquery and Underscore are in asset folder

It was seen while developing that only two countries and 2 cities have record associated with the database

Country -> Canada City-> Lethbridge


--Comments In Code---
I have tried to Leave as much possible Comments in the Code




